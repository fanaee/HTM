function [ anomalies_t2,anomalies_individual,pvalues,pvalues2 ] = Tensor2P( M , t, threshold)
[COEFF,SCORE,latent,t2] = princomp(M);
pvalues = 1-chi2cdf(t2,size(M,2));
anomalies_t2=t(find(pvalues<=threshold));
pvalues2=PI(M);
anomalies_individual=t(find(pvalues2<=threshold));
pvalues2=pvalues2';