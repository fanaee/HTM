% ********************************************
% HTM algorithm
% Fanaee-T, Hadi, and Gama, Joao. "Event detection from traffic tensors: A hybrid model." Neurocomputing 203 (2016): 22-33.
%
% ********************************************
addpath(genpath('tensor_toolbox_2.5'));
addpath(genpath('MBI'));

ts=tensor(cnt);
tsf=tensor(Xf);
sigma = 2; c=15;  lambda = 0.005 * norm(ts); 
[f31 fit_TD2 rankd{2,1}] = main_alg2(c,ts,ts,lambda,sigma);
sigma = 2; c=15;  lambda = 0.005 * norm(tsf); 
[f32 fit_TD2 rankd{2,1}] = main_alg2(c,tsf,tsf,lambda,sigma);
newfactor=[f31 f32];  %flow+topology
[anomalies1 anomalies2 p1 p2]=Tensor2P(newfactor,DateID,0.05);
HTM_method=anomalies1;
