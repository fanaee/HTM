function [newA1 newA2 newA3 newy1 newy2 newy3 maxoptv] = ...
    tucker_penalty(T,A1,A2,A3,y1,y2,y3, iter, lambda, c,error)

k = iter; 
v = zeros(10,1); u = zeros(20,1);
a = zeros(3,1);

n = T.size;
n1 = n(1); n2 = n(2); n3 = n(3);


% Compute f(T,A1,A2,A3,y1,y2,y3)
v(1) = obj(T,A1,A2,A3,y1,y2,y3,lambda,c); 
u(1) = v(1); i = 1;

Y1 = diag(y1); Y2 = diag(y2); Y3 = diag(y3);
B1 = A1 * Y1; B2 =  A2 * Y2; B3 = A3 * Y3;

while (abs(u(i)) > error) && (i < k) 
    i = i + 1;

% Block Improvement
    
    % fix A2,Y2,A3,Y3, find optimal A1, Y1 \in R^{n1 * n1}
    C1 = ttm(T, { B2', B3'}, [2 3]);
    % unfolding C1 in mode 1
    W1 = tenmat(C1, 1, [2 3]);
    W1 = double(W1);
    [U1,S1,V1] = svd(W1);
    A1 = U1(:,1:min(n1,c));
    % find optimal Y1 and optimal value
    c1 = c - sum(y2) - sum(y3);
    [barY1 opt1]= comb_opty(A1'*W1,lambda,c1);
    a(1) = opt1;
    
    % fix A1,Y1,A3,Y3, find optimal A2, Y2 \in R^{n2 * n2}
    C2 = ttm(T, { B1', B3'}, [1 3]);
    % unfolding C2 in mode 2
    W2 = tenmat(C2, 2, [1 3]);
    W2 = double(W2);
    [U2,S2,V2] = svd(W2); 
    A2 = U2(:,1:min(n2,c));
    % find optimal Y2 and optimal value
    c2 = c - sum(y1) - sum(y3);
    [barY2 opty2] = comb_opty(A2'*W2,lambda,c2);
    a(2) = opty2;
    
    % fix A1,Y1,A2,Y2, find optimal A3, Y3 \in R^{n3 * n3}
    C3 = ttm(T, { B1', B2'}, [1 2]);
    % unfolding C3 in mode 3
    W3 = tenmat(C3, 3, [1 2]);
    W3 = double(W3);
    [U3,S3,V3] = svd(W3);
    A3 = U3(:,1:min(n3,c));
    % find optimal Y3 and optimal value
    c3 = c - sum(y1) - sum(y2);
    [barY3 opty3] = comb_opty(A3'*W3,lambda,c3);
    a(3) = opty3;
  
 % Maximum Improvement
    [v(i),index] = max(a);
    
 % Update only one pair (Ai,Yi),i=1,2,3
    if index == 1
         Y1 = barY1;
         if sum(Y1) == 0
             fprintf('no quota in position 1');
             break;
         end
         B1 = A1 * Y1;
    end
    if index == 2
         Y2 = barY2;
         if sum(Y2) == 0
            fprintf('no quota in position 2');
            break;
         end
         B2 = A2 * Y2;
    end
    if index == 3
         Y3 = barY3;
         if sum(Y3) == 0
            fprintf('no quota in position 3');
            break;
         end
         B3 = A3 * Y3;
    end
    
    u(i) = v(i) - v(i-1);
    
    if i==k
        fprintf('need more iterations, please increase iter');
    end
    
end

newy1 = zeros(1,length(Y1(:,1)));
newy2 = zeros(1,length(Y2(:,1)));
newy3 = zeros(1,length(Y3(:,1)));

% Output: update matrces A1,A2,A3,Y2,Y3,Y3
newA1 = A1; newA2 = A2; newA3 = A3;
for i = 1 : length(Y1(:,1))
newy1(i) = Y1(i,i); 
end
for i = 1:length(Y2(:,1))
newy2(i) = Y2(i,i); 
end
for i = 1: length(Y3(:,1))
newy3(i) = Y3(i,i);
end
maxoptv=v;
