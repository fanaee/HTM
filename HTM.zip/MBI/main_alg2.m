function [F3 fit_TD2 rank estT] = main_alg2(c,Y,E,lambda,sigma)

% tucker decomposition with unknown number of components
%Input: 
% c         a given constant for the summation of all i-ranks, say r_1+r_2+r_3=c
% Y         third order tensor (with noise) to decompose
% E         third order tensor (without noise)
%           if there is no noise, then Y = E
% lambda    a penalty parameter
% sigma     a penalty parameter

%Output: 
% fit_TD2    to measure how good is the tucker approximation to tensor E
% rank_TD2   i-ranks information, that is, r_1, r_2 and r_3

T = Y;

n = T.size;
n1 = n(1); n2 = n(2); n3 = n(3);

% initial matrices A1,A2,A3 
oldA1 = randn(n1,min(n1,c));  
oldA2 = randn(n2,min(n2,c)); 
oldA3 = randn(n3,min(n3,c));

A1 = gramschmidt(oldA1);
A2 = gramschmidt(oldA2);
A3 = gramschmidt(oldA3);

% initial rank estimation, and then compute initial y_i, 
% where matrices Yi=diag(yi),i=1,2,3. 
r1 = 1; y1 = [ones(1, r1) zeros(1,min(n1,c)-r1)];
r2 = 1; y2 = [ones(1, r2) zeros(1,min(n2,c)-r2)];
r3 = 1; y3 = [ones(1, r3) zeros(1,min(n3,c)-r3)];

iter = 150; 

outeriter = 30; outerk = 0;
while outerk < outeriter

if outerk <= 3
    error = 1.0e-3;
else
    error = 1.0e-4;
end
    
[newA1 newA2 newA3 newy1 newy2 newy3 maxoptv1] = ...
tucker_penalty(T,A1,A2,A3,y1,y2,y3, iter, lambda, c, error);

outerk = outerk + 1;

if outerk == outeriter
    fprintf('\n please increase outeriter');
end

% update
A1 = newA1; A2 = newA2; A3 = newA3;
y1 = newy1; y2 = newy2; y3 = newy3; 
lambda = sigma * lambda;

clear newA1; clear newA2; clear newA3; 
clear newy1;clear newy2;clear newy3;

if sum(y1) + sum(y2) + sum(y3) == c
   fprintf('\n summation of ranks equals to c \n');
   break;
end

end


 F1 = A1 * diag(y1); 
 F2 = A2 * diag(y2); 
 F3 = A3 * diag(y3);  
 
core = ttm(T, {F1', F2', F3'}, [1 2 3]);
estT = ttm(core,{F1,F2,F3}, [1 2 3]);

fit_exact = 1- norm(tensor(double(E)- double(estT)))/norm(E);

% Output
rank = [sum(y1) sum(y2) sum(y3)];
fit_TD2 =  fit_exact;