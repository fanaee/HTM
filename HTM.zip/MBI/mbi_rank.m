function [maxoptx1,maxoptx2,maxoptx3,maxoptv,vv] = mbi_rank(A1,A2,A3,F,iter,error)
% Algorithm 1 in our paper

k = iter;
v=zeros(20,1); u=zeros(20,1);

a=zeros(3,1);

% Compute F(A1,A2,A3)
faaa = ttm(F, {A1',A2',A3'}, [1 2 3]);
v(1) = norm(faaa); u(1) = v(1); i = 1;

% Maximum Improvement Method
while (abs(u(i)) > error) && (i < k) 
    i = i + 1;
  
  % alternate in each step  
  
    B1 = ttm(F,{A2', A3'}, [2 3]);
    % unfolding B1 in mode 1
    W1 = tenmat(B1, 1, [2 3]);
    W1 = double(W1); 

    B2 = ttm(F,{A1', A3'}, [1 3]);
    % unfolding B2 in mode 2
    W2 = tenmat(B2, 2, [1 3]);
    W2 = double(W2);
    
    B3 = ttm(F,{A1', A2'}, [1 2]);
    % unfolding A in mode 3
    W3 = tenmat(B3, 3, [1 2]);
    W3 = double(W3);
    clear B1; clear B2; clear B3; 
   
    
    [U1,S1,V1]=svd(W1); [U2,S2,V2]=svd(W2); [U3,S3,V3]=svd(W3); 
    
    barA1 = U1(:,1:length(A1(1,:))); 
    barA2 = U2(:,1:length(A2(1,:))); 
    barA3 = U3(:,1:length(A3(1,:)));

    a(1) = norm(barA1' * W1,'fro'); 
    a(2) = norm(barA2' * W2,'fro');
    a(3) = norm(barA3' * W3,'fro'); 
    
    [v(i),index] = max(a);
    
    if index == 1
        A1 = barA1;
    end
    if index == 2
        A2 = barA2;
    end
    if index == 3
        A3 = barA3;
    end

    u(i) = v(i) - v(i-1);
    
    if i==k
        fprintf('need more iterations, please increase iter');
    end
end


% optimal solution (A1,A2,A3) , optimal value v(i) 
% when algorithm 1 stops
maxoptx1=A1;
maxoptx2=A2;
maxoptx3=A3;
maxoptv=v(i);
vv=v;