function  [Y opt_val] = comb_opty(S,lambda,c)

% slove a maxmimum quadratic optimization problem
% which is a combinatorial problem, but it is polynomial-time solvable

n = length(S(:,1));
e = ones(n,1);

w = zeros(1,n);
for i=1:n
    w(i) = norm(S(i,:))^2;
end

hatc = w' + 2 * lambda * c * e;
[y ix] = sort(hatc, 'descend');

obj = zeros(n,1);
for i=1:n
    obj(i) = - lambda * i^2 + sum(y(1:i));
end
[opt index] = max(obj);

% Output:
% optimal value
opt_val = opt - lambda * c^2;

% optimal solution for diagonal matrix Y 
opty = [ones(1, index) zeros(1, n-index)];
Y = diag(opty);


