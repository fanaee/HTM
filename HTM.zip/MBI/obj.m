
function f = obj(T,A1,A2,A3,y1,y2,y3,lambda,c)

% Compute the objective function of maximization problem
% objective funtion: 
%     f(T,A1,A2,A3,Y1,Y2,Y3) - penalty term

B1 = A1 * diag(y1); B2 = A2 * diag(y2); B3= A3 * diag(y3);
core = ttm(T, {B1',B2',B3'}, [1 2 3]);

f = norm(core)^2 - lambda * ( sum(y1)+sum(y2)+sum(y3) - c )^2;