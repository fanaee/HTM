function [C3 fit_TD3 rank_TD3] = heuristic(c, Y, E)

% Heuristic approach (Algorithm 3 in our paper)

%Input: 
% c      a given constant for the summation of all i-ranks, say r_1+r_2+r_3=c
% Y      third order tensor (with noise) to decompose
% E      third order tensor (without noise)
%        if there is no noise, then Y = E

%Output: 
% fit_TD3    to measure how good is the tucker approximation to tensor E
% rank_TD3   i-ranks information, that is, r_1, r_2 and r_3

X = Y;
normX = norm(X);

n = X.size;
n1 = n(1); n2 = n(2); n3 = n(3);

% initial ranks for r_1, r_2 and r_3
r1 = min(c, n1); r2 = min(c, n2); r3 = min(c, n3); 

% initial matrices for A1, A2, A3
A1 = randn(n1,r1); A1 = gramschmidt(A1);
A2 = randn(n2,r2); A2 = gramschmidt(A2);
A3 = randn(n3,r3); A3 = gramschmidt(A3);


iter = 100;

%%%%%%%%%%%%%%%%%%%% MBI procedure %%%%%%%%%%%%%%%%%%%%%%%%%%%
error1=1.0e-2;
[maxA1,maxA2,maxA3,maxoptv,vv] = mbi_rank(A1,A2,A3,X,iter,error1);

%%%%%%%%%%%%%%%%%%%%%%% heuristic procudure to reduce rank %%%%%%%%%%%%%%
[s1 s2 s3 B1 B2 B3 bestnewfit] = reduce_rank(maxA1,maxA2,maxA3,c,X,normX);

%%%%%%%%%%%%%%%%%%%% MBI procedure %%%%%%%%%%%%%%%%%%%%%%%%%%%
error2 = 1.0e-4; 
[C1,C2,C3,optCv,Cvv] = mbi_rank(B1,B2,B3,X,iter,error2);

% compute core tensor and tucker approximation tensor
core = ttm(Y,{C1',C2',C3'}, [1 2 3]);
estT = ttm(core,{C1,C2,C3}, [1 2 3]);

fit_mbi_exact = 1- norm(tensor(double(E)- double(estT)))/norm(E);

%Output
fit_TD3 = fit_mbi_exact;
rank_TD3 = [s1 s2 s3];


