function [s1 s2 s3 B1 B2 B3 bestnewfit] = reduce_rank(maxA1,maxA2,maxA3,c,X,normX)

% select one of the i-ranks to decrease

r1 = length(maxA1(1,:));
r2 = length(maxA2(1,:));
r3 = length(maxA3(1,:));

sum_rank = r1 + r2 + r3;

while sum_rank > c

md1 = maxA1(:,1:r1-1); 
md2 = maxA2(:,1:r2-1); 
md3 = maxA3(:,1:r3-1);

newfit = zeros(3,1);
% make a change in mode 1
core1 = ttm(X, {md1',maxA2',maxA3'}, [1 2 3]);
newfit(1) = 1 - sqrt(normX^2 - norm(core1)^2)/normX;

% make a change in mode 2
core2 = ttm(X, {maxA1',md2',maxA3'}, [1 2 3]);
newfit(2) = 1 - sqrt(normX^2 - norm(core2)^2)/normX;

% make a change in mode 3
core3 = ttm(X, {maxA1',maxA2',md3'}, [1 2 3]);
newfit(3) = 1 - sqrt(normX^2 - norm(core3)^2)/normX;

% select the best one among the above three ways
[bestnewfit pos]= max(newfit);

if pos == 1
   B1 = maxA1(:,1:r1-1);
   B2 = maxA2;
   B3 = maxA3;
   r1 = r1 -1;
  % fprintf('\n reduce rank in mode 1');
end

if pos == 2
   B1 = maxA1;
   B2 = maxA2(:,1:r2-1);
   B3 = maxA3;
   r2 = r2-1;
  % fprintf('\n reduce rank in mode 2');
end

if pos == 3
   B1 = maxA1;
   B2 = maxA2;
   B3 = maxA3(:,1:r3-1);
   r3 = r3 -1;
  % fprintf('\n reduce rank in mode 3');
end

sum_rank = r1+ r2 + r3;
end

%output the i-ranks(r_1, r_2 and r_3)
s1 = r1; s2 = r2; s3 = r3;
